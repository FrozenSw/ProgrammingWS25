#ifndef SORT_H
#define SORT_H

#include<iostream>

void Read(int a[], int& size, int max_size);
void Print(const int[], int);
void BubbleSort(int a[], int size);

#endif

