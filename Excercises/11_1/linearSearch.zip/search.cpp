#include "search.h"

using std::cout;
using std::cin;
using std::endl;

/** 
  * Read in array with maximum max_size elements
  * Number of read in elements is stored in size_ref
  */
void read( int a[], int& size_ref, int max_size ){
    size_ref = 0;
    do {
        cout << "a[" << size_ref << "]: ";
        cin >> a[size_ref++];
    // Quit when max_size is reached or EOF has been entered (CTRL+d, CTRL+z)    
    } while(size_ref < max_size && !cin.eof());
    // Clear cin and decrement size_ref after EOF has been entered
    if(cin.eof()) {
        cout << endl;
        size_ref--;
        cin.clear();
    }
}

/**
  * Print size elements of array separated by one space
  */
void print( const int a[], int size ){
    for(int i = 0; i < size; i++) {
        cout << a[i] << " ";
    }
}

/**
  * Run through array and check if key is found
  * Return index if found, or -1
  */
int linearSearch( const int array[], int key, int size ){
    for(int i = 0; i < size; i++) {
        if(array[i] == key) return i;
    }
    return -1;
} 
